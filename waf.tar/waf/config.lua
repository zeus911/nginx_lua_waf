RulePath = "/opt/nginx/conf/waf/wafconf/"
attacklog = "on"
logdir = "/opt/nginx/logs/hack/"
UrlDeny="on"
Redirect="on"
CookieMatch="on"
postMatch="on" 
whiteModule="on" 
black_fileExt={"php","jsp"}
ipWhitelist={"127.0.0.1"}
ipBlocklist={"1.0.0.1"}
CCDeny="off"
CCrate="100/60"
html=[[

<font color="red"> <h1>Firewall Intercept</h1> </font >
]]
